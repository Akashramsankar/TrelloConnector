const TRELLO_AUTH_POPUP_NAME = "trello-connector-auth";
const TRELLO_AUTH_TIMEOUT_MS = 120000;
const TRELLO_CALLBACK_PAGE_URL = "https://akashramsankar.github.io/TrelloConnector/trello_auth_complete.html";
const TRELLO_CALLBACK_ORIGIN = new URL(TRELLO_CALLBACK_PAGE_URL).origin;
const DEFAULT_TRELLO_BRIDGE_HOST = "trello-connector-bridge.akashram-trello-bridge.workers.dev";
const TRELLO_TO_FRESHDESK_EVENTS = [
  { key: "ticket_linked", label: "A ticket is connected to a Trello card" },
  { key: "card_moved", label: "A linked card is moved to another list" },
  { key: "card_comment_added", label: "Someone comments on a linked card" },
  { key: "card_member_added", label: "A member is added to a linked card" },
  { key: "card_labels_updated", label: "Labels change on a linked card" },
  { key: "card_due_date_updated", label: "The due date changes on a linked card" },
  { key: "card_attachment_added", label: "A file is attached to a linked card" },
  { key: "card_archived", label: "A linked card is archived" },
];
const FRESHDESK_TO_TRELLO_EVENTS = [
  { key: "ticket_linked", label: "A ticket is connected to a Trello card" },
  { key: "private_note_added", label: "A private note is added to the ticket" },
  { key: "public_note_added", label: "A public note is added to the ticket" },
  { key: "agent_reply_added", label: "An agent reply is sent from the ticket" },
  { key: "ticket_forwarded", label: "The ticket is forwarded" },
];
const FRESHDESK_ACTION_OPTIONS = [
  { value: "none", label: "Leave the ticket unchanged" },
  { value: "private_note_notify", label: "Add a private note and alert the assignee" },
  { value: "public_note", label: "Add a public note on the ticket" },
];
const TRELLO_ACTION_OPTIONS = [
  { value: "none", label: "Do not post anything" },
  { value: "comment", label: "Add a comment to the linked Trello card" },
];
const DEFAULT_TRELLO_TO_FRESHDESK_ACTION = "private_note_notify";
const DEFAULT_FRESHDESK_TO_TRELLO_ACTION = "comment";

const state = {
  client: null,
  initialized: false,
  initializing: null,
  hydrating: false,
  autoPopupAttempted: false,
  savedConfigs: {},
  sessionSecrets: {
    trelloToken: "",
    freshdeskAuth: "",
  },
  trelloVerified: false,
  freshdeskVerified: false,
  trelloAuthInFlight: false,
  trelloAuthTimeoutId: null,
  connectedTrelloMember: null,
  notificationPreferences: {
    trelloToFreshdesk: {},
    freshdeskToTrello: {},
  },
};

const refs = {};
const FRESHDESK_KEY_PLACEHOLDER = "Freshdesk API Key";
const PROMO_APPS = [
  {
    name: "Schedule Replies Pro",
    description: "Schedule Freshdesk replies for the exact follow-up moment.",
    appId: "378042",
    publicUrl: "https://www.freshworks.com/apps/schedule_replies_pro/",
    icon: "./assets/schedule-replies-pro.png",
  },
  {
    name: "Attachments Preview Pro",
    description: "Preview ticket attachments faster without extra downloads.",
    appId: "378223",
    publicUrl: "https://www.freshworks.com/apps/attachments_preview_pro_2/",
    icon: "./assets/attachments-preview-pro.png",
  },
  {
    name: "Schedule Ticket Pro",
    description: "Plan ticket actions and reminders around team workflows.",
    appId: "378481",
    publicUrl: "https://www.freshworks.com/apps/schedule_ticket_pro/",
    icon: "./assets/schedule-ticket-pro.png",
  },
];

document.addEventListener("DOMContentLoaded", () => {
  void ensureInitialized();
});

function ensureInitialized() {
  if (!state.initializing) {
    state.initializing = initialize();
  }
  return state.initializing;
}

async function initialize() {
  state.client = await app.initialized();
  bindRefs();
  renderPromoApps();
  bindEvents();
  state.initialized = true;
  await hydrateFromConfigs(state.savedConfigs);
}

function bindRefs() {
  refs.connectTrelloBtn = document.getElementById("connectTrelloBtn");
  refs.resetTrelloBtn = document.getElementById("resetTrelloBtn");
  refs.trelloStatusLine = document.getElementById("trelloStatusLine");
  refs.trelloConnectionSummary = document.getElementById("trelloConnectionSummary");
  refs.trelloMemberName = document.getElementById("trelloMemberName");
  refs.trelloMemberMeta = document.getElementById("trelloMemberMeta");
  refs.trelloMessage = document.getElementById("trelloMessage");

  refs.domain = document.getElementById("domain");
  refs.apiKey = document.getElementById("apiKey");
  refs.verifyFreshdeskBtn = document.getElementById("verifyFreshdeskBtn");
  refs.freshdeskStatusLine = document.getElementById("freshdeskStatusLine");
  refs.freshdeskMessage = document.getElementById("freshdeskMessage");

  refs.installerName = document.getElementById("installerName");
  refs.installerNameMessage = document.getElementById("installerNameMessage");
  refs.installerEmail = document.getElementById("installerEmail");
  refs.installerEmailMessage = document.getElementById("installerEmailMessage");
  refs.promoApps = document.getElementById("promoApps");

  refs.notificationSettingsSection = document.getElementById("notificationSettingsSection");
  refs.trelloToFreshdeskList = document.getElementById("trelloToFreshdeskList");
  refs.freshdeskToTrelloList = document.getElementById("freshdeskToTrelloList");
}

function bindEvents() {
  refs.connectTrelloBtn.addEventListener("click", (event) => {
    clearMessage(refs.trelloMessage);
    if (!refs.connectTrelloBtn.href || refs.connectTrelloBtn.href.endsWith("#")) {
      event.preventDefault();
      showMessage(refs.trelloMessage, "Trello sign-in link is not ready yet. Refresh and try again.", "error");
      return;
    }
    markTrelloAuthPending();
    const opened = openTrelloAuthPopup(refs.connectTrelloBtn.href);
    if (opened) {
      event.preventDefault();
      showMessage(refs.trelloMessage, "Finish signing into Trello in the popup window.", "info");
      return;
    }
    showMessage(refs.trelloMessage, "Popup was blocked, so Trello will open in a new tab instead.", "info");
  });

  refs.resetTrelloBtn.addEventListener("click", (event) => {
    clearTrelloConnection({ clearSavedConfigKey: true });
    clearMessage(refs.trelloMessage);
    if (!refs.resetTrelloBtn.href || refs.resetTrelloBtn.href.endsWith("#")) {
      event.preventDefault();
      showMessage(refs.trelloMessage, "Trello sign-in link is not ready yet. Refresh and try again.", "error");
      return;
    }
    markTrelloAuthPending();
    const opened = openTrelloAuthPopup(refs.resetTrelloBtn.href);
    if (opened) {
      event.preventDefault();
      showMessage(refs.trelloMessage, "Finish signing into Trello in the popup window.", "info");
      return;
    }
    showMessage(refs.trelloMessage, "Popup was blocked, so Trello will open in a new tab instead.", "info");
  });

  refs.verifyFreshdeskBtn.addEventListener("click", () => {
    void verifyFreshdeskCredentials();
  });

  refs.domain.addEventListener("input", () => {
    clearMessage(refs.freshdeskMessage);
    clearFreshdeskVerification();
    renderPromoApps();
  });

  refs.installerName.addEventListener("input", () => {
    clearMessage(refs.installerNameMessage);
  });
  refs.installerEmail.addEventListener("input", () => {
    clearMessage(refs.installerEmailMessage);
  });

  refs.apiKey.addEventListener("input", () => {
    clearMessage(refs.freshdeskMessage);
    clearFreshdeskVerification();
  });

  refs.trelloToFreshdeskList.addEventListener("change", handleNotificationSelectionChange);
  refs.freshdeskToTrelloList.addEventListener("change", handleNotificationSelectionChange);

  window.addEventListener("message", (event) => {
    void handleTrelloAuthMessage(event);
  });
}

async function hydrateFromConfigs(configs) {
  if (!state.initialized || state.hydrating) {
    return;
  }

  state.hydrating = true;

  try {
    const safeConfigs = configs || {};

    refs.domain.value = safeConfigs.domain || "";
    refs.installerName.value = safeConfigs.installer_name || "";
    refs.installerEmail.value = safeConfigs.installer_email || "";
    renderPromoApps();
    refs.apiKey.value = safeConfigs.api_key ? getMaskedSecretPlaceholder() : "";
    refs.apiKey.setAttribute("placeholder", FRESHDESK_KEY_PLACEHOLDER);

    state.sessionSecrets.trelloToken = safeConfigs.trello_token || "";
    state.sessionSecrets.freshdeskAuth = safeConfigs.api_key || "";
    state.trelloVerified = hasSavedTrelloConnection(safeConfigs);
    state.freshdeskVerified = hasSavedFreshdeskConnection(safeConfigs);
    state.connectedTrelloMember = safeConfigs.trello_member_name
      ? {
          name: safeConfigs.trello_member_name,
          username: safeConfigs.trello_member_username || "",
          url: safeConfigs.trello_member_url || "",
        }
      : null;
    state.notificationPreferences = {
      trelloToFreshdesk: normalizeNotificationPreferences(
        safeConfigs.trello_to_freshdesk_notifications,
        TRELLO_TO_FRESHDESK_EVENTS,
        resolveTrelloToFreshdeskMode(safeConfigs)
      ),
      freshdeskToTrello: normalizeNotificationPreferences(
        safeConfigs.freshdesk_to_trello_notifications,
        FRESHDESK_TO_TRELLO_EVENTS,
        resolveFreshdeskToTrelloMode(safeConfigs)
      ),
    };

    await refreshTrelloAuthorizationLinks();
    renderNotificationSettings();
    updateTrelloStatus();
    updateFreshdeskStatus();
    updateNotificationVisibility();
  } finally {
    state.hydrating = false;
  }

  maybeAutoOpenTrelloPopup();
}

function hasSavedTrelloConnection(configs) {
  return Boolean(
    configs &&
      (configs.trello_token ||
        configs.trello_token_fingerprint ||
        configs.trello_member_name)
  );
}

function hasSavedFreshdeskConnection(configs) {
  return Boolean(configs && normalizeDomain(configs.domain));
}

function getSecureIparamsMask() {
  return String.fromCharCode(42).repeat(24);
}

function normalizeBridgeHost(value) {
  return String(value || "")
    .trim()
    .replace(/^https?:\/\//i, "")
    .replace(/\/+$/, "");
}

function getActiveTrelloBridgeHost() {
  return normalizeBridgeHost(DEFAULT_TRELLO_BRIDGE_HOST);
}

function getActiveTrelloToken() {
  const token = String(state.sessionSecrets.trelloToken || state.savedConfigs.trello_token || "").trim();
  return token || (hasSavedTrelloConnection(state.savedConfigs) ? getSecureIparamsMask() : "");
}

function buildTokenFingerprint(token) {
  const normalized = String(token || "").trim();
  if (!normalized || normalized === getSecureIparamsMask()) {
    return "";
  }

  const suffix = normalized.slice(-4);
  return `len:${normalized.length}:end:${suffix}`;
}

function getActiveFreshdeskAuth() {
  const freshdeskKey = String(refs.apiKey.value || "").trim();
  if (freshdeskKey && freshdeskKey !== getMaskedSecretPlaceholder()) {
    return btoa(`${freshdeskKey}:X`);
  }

  return (
    state.sessionSecrets.freshdeskAuth ||
    state.savedConfigs.api_key ||
    (hasSavedFreshdeskConnection(state.savedConfigs) ? getSecureIparamsMask() : "")
  );
}

function getMaskedSecretPlaceholder() {
  return getSecureIparamsMask();
}

function resetTrelloAuthorizationLinks() {
  refs.connectTrelloBtn.href = "#";
  refs.resetTrelloBtn.href = "#";
  refs.connectTrelloBtn.target = TRELLO_AUTH_POPUP_NAME;
  refs.resetTrelloBtn.target = TRELLO_AUTH_POPUP_NAME;
}

async function refreshTrelloAuthorizationLinks() {
  const trelloBridgeHost = getActiveTrelloBridgeHost();
  const returnUrl = buildTrelloAuthReturnUrl();

  resetTrelloAuthorizationLinks();

  if (!trelloBridgeHost) {
    return;
  }

  try {
    const response = await state.client.request.invokeTemplate("trello_authorize_url", {
      context: {
        trello_bridge_host: trelloBridgeHost,
        return_url: encodeURIComponent(returnUrl),
      },
    });

    if (Number(response.status) !== 200) {
      throw new Error("Trello authorization URL is not available.");
    }

    const payload = safeParseJson(response.response, {});
    const authorizeUrl = String(payload.authorize_url || payload.url || "").trim();
    if (!authorizeUrl) {
      throw new Error("Trello authorization URL is empty.");
    }

    refs.connectTrelloBtn.href = authorizeUrl;
    refs.resetTrelloBtn.href = authorizeUrl;
  } catch (error) {
    console.error("Failed to prepare Trello sign-in link:", error);
    showMessage(refs.trelloMessage, "Trello sign-in link is not ready yet. Check the bridge host.", "error");
  }
}

function buildTrelloAuthReturnUrl() {
  const callbackUrl = new URL(TRELLO_CALLBACK_PAGE_URL);
  callbackUrl.searchParams.set("parent_origin", window.location.origin);
  return callbackUrl.toString();
}

function maybeAutoOpenTrelloPopup() {
  if (state.autoPopupAttempted || state.trelloVerified || state.trelloAuthInFlight) {
    return;
  }

  state.autoPopupAttempted = true;

  if (!refs.connectTrelloBtn.href || refs.connectTrelloBtn.href.endsWith("#")) {
    return;
  }

  markTrelloAuthPending();
  const opened = openTrelloAuthPopup(refs.connectTrelloBtn.href);

  if (opened) {
    showMessage(refs.trelloMessage, "Trello sign-in opened automatically. Finish signing in to continue.", "info");
    return;
  }

  cleanupTrelloAuthFlow();
  showMessage(refs.trelloMessage, "If Trello did not open automatically, click Connect Trello to continue.", "info");
}

async function handleTrelloAuthMessage(event) {
  const isTrelloMessage = event && event.origin === "https://trello.com";
  const isHostedCallbackMessage =
    event &&
    event.origin === TRELLO_CALLBACK_ORIGIN &&
    event.data &&
    typeof event.data === "object" &&
    event.data.source === "trello-auth-callback";

  if (!isTrelloMessage && !isHostedCallbackMessage) {
    return;
  }

  cleanupTrelloAuthFlow();

  const data = event.data;
  const message = typeof data === "string" ? data.trim() : "";
  const token =
    typeof data === "string"
      ? data.trim()
      : data && typeof data.token === "string"
      ? data.token.trim()
      : "";
  const error =
    data && typeof data === "object" && typeof data.error === "string"
      ? data.error.trim()
      : message.toLowerCase().includes("rejected")
      ? message
      : "";

  if (error) {
    showMessage(refs.trelloMessage, "Trello authorization was cancelled. Click Connect Trello to try again.", "error");
    return;
  }

  if (!token) {
    showMessage(refs.trelloMessage, "Trello did not return a token. Click Connect Trello to try again.", "error");
    return;
  }

  await verifyTrelloConnection(token);
}

async function verifyTrelloConnection(token) {
  const trelloBridgeHost = getActiveTrelloBridgeHost();

  if (!trelloBridgeHost) {
    showMessage(refs.trelloMessage, "Trello bridge is not configured for this app yet.", "error");
    return;
  }

  try {
    showMessage(refs.trelloMessage, "Verifying Trello connection...", "info");

    const response = await state.client.request.invokeTemplate("verify_trello_connection", {
      context: {
        trello_bridge_host: trelloBridgeHost,
        trello_token: token,
      },
    });

    if (Number(response.status) !== 200) {
      throw new Error("Trello credentials are not valid.");
    }

    const payload = safeParseJson(response.response, {});
    state.sessionSecrets.trelloToken = token;
    state.trelloVerified = true;
    state.connectedTrelloMember = normalizeTrelloMember(payload);

    updateTrelloStatus();
    updateNotificationVisibility();
    showMessage(refs.trelloMessage, "Trello connected.", "success");
  } catch (error) {
    console.error("Failed to verify Trello connection:", error);
    clearTrelloConnection({ clearSavedConfigKey: false });
    showMessage(refs.trelloMessage, "Could not verify Trello. Click Connect Trello to try again.", "error");
  }
}

function normalizeTrelloMember(payload) {
  return {
    name: String(payload && (payload.fullName || payload.username || "Trello member")).trim(),
    username: String(payload && payload.username ? payload.username : "").trim(),
    url: String(payload && payload.url ? payload.url : "").trim(),
  };
}

async function verifyFreshdeskCredentials() {
  const domain = normalizeDomain(refs.domain.value);
  const encodedAuth = getActiveFreshdeskAuth();
  clearMessage(refs.freshdeskMessage);

  if (!domain) {
    showMessage(refs.freshdeskMessage, "Enter the Freshdesk domain.", "error");
    return;
  }

  if (!encodedAuth) {
    showMessage(refs.freshdeskMessage, "Enter the Freshdesk API key.", "error");
    return;
  }

  try {
    showMessage(refs.freshdeskMessage, "Verifying Freshdesk...", "info");

    const response = await state.client.request.invokeTemplate("verify_freshdesk_credentials", {
      context: {
        domain,
        encoded_auth: encodedAuth,
      },
    });

    if (Number(response.status) !== 200) {
      throw new Error("Freshdesk credentials are not valid.");
    }

    state.freshdeskVerified = true;
    state.sessionSecrets.freshdeskAuth = encodedAuth;
    refs.domain.value = domain;

    updateFreshdeskStatus();
    updateNotificationVisibility();
    showMessage(refs.freshdeskMessage, "Freshdesk verified.", "success");
  } catch (error) {
    console.error("Failed to verify Freshdesk credentials:", error);
    clearFreshdeskVerification();
    showMessage(refs.freshdeskMessage, "Could not verify Freshdesk. Check the domain and API key.", "error");
  }
}

function markTrelloAuthPending() {
  cleanupTrelloAuthFlow();
  state.trelloAuthInFlight = true;
  refs.connectTrelloBtn.disabled = true;

  state.trelloAuthTimeoutId = window.setTimeout(() => {
    cleanupTrelloAuthFlow();
    showMessage(refs.trelloMessage, "Trello sign-in timed out. Click Connect Trello to try again.", "error");
  }, TRELLO_AUTH_TIMEOUT_MS);
}

function openTrelloAuthPopup(url) {
  try {
    const popup = window.open(
      url,
      TRELLO_AUTH_POPUP_NAME,
      "width=720,height=760,menubar=no,toolbar=no,location=yes,resizable=yes,scrollbars=yes,status=no"
    );
    return Boolean(popup);
  } catch (error) {
    console.error("Failed to open Trello popup:", error);
    return false;
  }
}

function cleanupTrelloAuthFlow() {
  state.trelloAuthInFlight = false;
  refs.connectTrelloBtn.disabled = false;

  if (state.trelloAuthTimeoutId) {
    window.clearTimeout(state.trelloAuthTimeoutId);
    state.trelloAuthTimeoutId = null;
  }
}

function clearTrelloConnection(options) {
  const settings = options || {};

  cleanupTrelloAuthFlow();
  state.sessionSecrets.trelloToken = "";
  state.trelloVerified = false;
  state.connectedTrelloMember = null;

  if (settings.clearSavedConfigKey) {
    state.savedConfigs.trello_token = "";
  }

  updateTrelloStatus();
  updateNotificationVisibility();
}

function clearFreshdeskVerification() {
  state.freshdeskVerified = false;
  state.sessionSecrets.freshdeskAuth = "";
  updateFreshdeskStatus();
  updateNotificationVisibility();
}

function updateTrelloStatus() {
  refs.trelloStatusLine.textContent = state.trelloVerified
    ? state.connectedTrelloMember && state.connectedTrelloMember.name
      ? `Connected as ${state.connectedTrelloMember.name}`
      : "Connected"
    : "Not connected";

  const visible = state.trelloVerified && state.connectedTrelloMember;
  refs.trelloConnectionSummary.classList.toggle("is-visible", Boolean(visible));

  if (!visible) {
    refs.trelloMemberName.textContent = "No Trello account connected yet.";
    refs.trelloMemberMeta.textContent = "";
    return;
  }

  refs.trelloMemberName.textContent = state.connectedTrelloMember.name;

  const details = [];
  if (state.connectedTrelloMember.username) {
    details.push(`@${state.connectedTrelloMember.username}`);
  }
  if (state.connectedTrelloMember.url) {
    details.push(state.connectedTrelloMember.url);
  }

  refs.trelloMemberMeta.textContent = details.join(" • ");
}

function updateFreshdeskStatus() {
  refs.freshdeskStatusLine.textContent = state.freshdeskVerified ? "Verified" : "Not verified";
}

function updateNotificationVisibility() {
  const ready = state.trelloVerified && state.freshdeskVerified;
  refs.notificationSettingsSection.classList.toggle("hidden", !ready);
}

function renderNotificationSettings() {
  refs.trelloToFreshdeskList.innerHTML = buildNotificationRows(
    TRELLO_TO_FRESHDESK_EVENTS,
    state.notificationPreferences.trelloToFreshdesk,
    FRESHDESK_ACTION_OPTIONS,
    "trelloToFreshdesk"
  );
  refs.freshdeskToTrelloList.innerHTML = buildNotificationRows(
    FRESHDESK_TO_TRELLO_EVENTS,
    state.notificationPreferences.freshdeskToTrello,
    TRELLO_ACTION_OPTIONS,
    "freshdeskToTrello"
  );
}

function buildNotificationRows(events, selections, options, group) {
  const fallbackValue =
    group === "trelloToFreshdesk" ? DEFAULT_TRELLO_TO_FRESHDESK_ACTION : DEFAULT_FRESHDESK_TO_TRELLO_ACTION;

  return events
    .map((event) => {
      const value = selections && selections[event.key] ? selections[event.key] : fallbackValue;
      return `
        <div class="notification-row">
          <div class="notification-label">${escapeHtml(event.label)}</div>
          <select class="notification-select" data-group="${escapeHtml(group)}" data-key="${escapeHtml(event.key)}">
            ${buildNotificationOptions(options, value)}
          </select>
        </div>
      `;
    })
    .join("");
}

function buildNotificationOptions(options, selectedValue) {
  return options
    .map((option) => {
      const selected = option.value === selectedValue ? " selected" : "";
      return `<option value="${escapeHtml(option.value)}"${selected}>${escapeHtml(option.label)}</option>`;
    })
    .join("");
}

function handleNotificationSelectionChange(event) {
  const select = event.target.closest("select[data-group][data-key]");
  if (!select) {
    return;
  }

  if (select.dataset.group === "trelloToFreshdesk") {
    state.notificationPreferences.trelloToFreshdesk[select.dataset.key] = select.value;
    return;
  }

  if (select.dataset.group === "freshdeskToTrello") {
    state.notificationPreferences.freshdeskToTrello[select.dataset.key] = select.value;
  }
}

function normalizeDomain(value) {
  const cleaned = String(value || "").trim().replace(/^https?:\/\//i, "").replace(/\/+$/, "");
  if (!cleaned) {
    return "";
  }
  return cleaned.includes(".") ? cleaned : `${cleaned}.freshdesk.com`;
}

function resolveTrelloToFreshdeskMode(configs) {
  const mode = String((configs && configs.trello_to_freshdesk_sync_mode) || "").trim().toLowerCase();
  if (["none", "private_note_notify", "public_note"].includes(mode)) {
    return mode;
  }
  return DEFAULT_TRELLO_TO_FRESHDESK_ACTION;
}

function resolveFreshdeskToTrelloMode(configs) {
  const mode = String((configs && configs.freshdesk_to_trello_sync_mode) || "").trim().toLowerCase();
  if (["none", "comment"].includes(mode)) {
    return mode;
  }
  return DEFAULT_FRESHDESK_TO_TRELLO_ACTION;
}

function normalizeNotificationPreferences(value, events, fallbackValue) {
  const parsed = safeParseJson(value, {});
  const output = {};

  events.forEach((event) => {
    const savedValue =
      parsed && typeof parsed === "object" && typeof parsed[event.key] === "string" ? parsed[event.key].trim() : "";
    output[event.key] = savedValue || fallbackValue;
  });

  return output;
}

function renderPromoApps() {
  if (!refs.promoApps) {
    return;
  }

  refs.promoApps.innerHTML = "";
  PROMO_APPS.forEach((appConfig) => {
    const link = document.createElement("a");
    link.className = "promo-card";
    link.href = getPromoAppUrl(appConfig);
    link.target = "_blank";
    link.rel = "noopener";

    const icon = document.createElement("img");
    icon.className = "promo-icon";
    icon.src = appConfig.icon;
    icon.alt = "";

    const body = document.createElement("div");
    const title = document.createElement("div");
    title.className = "promo-title";
    title.textContent = appConfig.name;

    const description = document.createElement("div");
    description.className = "promo-description";
    description.textContent = appConfig.description;

    body.appendChild(title);
    body.appendChild(description);
    link.appendChild(icon);
    link.appendChild(body);
    refs.promoApps.appendChild(link);
  });
}

function getConfiguredFreshdeskDomain() {
  return normalizeDomain((refs.domain && refs.domain.value) || state.savedConfigs.domain || "");
}

// freshworks.com pages are blocked when opened from the settings iframe, so link to the
// account's own in-product marketplace whenever the Freshdesk domain is known.
function getPromoAppUrl(appConfig) {
  const domain = getConfiguredFreshdeskDomain();

  if (!domain || !domain.includes(".freshdesk.com")) {
    return appConfig.publicUrl;
  }

  const params = new URLSearchParams({
    route: "app",
    id: appConfig.appId,
    utmCampaign: "REC_EXIST_CUST",
  });

  return `https://${domain}/a/admin/marketplace/gallery?${params.toString()}`;
}

function getInstallerName() {
  return String(refs.installerName.value || "").trim();
}

function getInstallerEmail() {
  return String(refs.installerEmail.value || "").trim().toLowerCase();
}

function isValidEmail(value) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

function getAppMetadata() {
  return window.FALCON_APP_METADATA || {
    appSlug: "freshdesk-trello-connector",
    appVersion: "unknown",
  };
}

function hasExistingInstallationConfig() {
  const configs = state.savedConfigs || {};
  return Boolean(configs.domain || configs.installer_email || configs.api_key);
}

function buildSettingsCapturePayload() {
  const metadata = getAppMetadata();

  return {
    app_slug: metadata.appSlug,
    app_version: metadata.appVersion,
    event: "settingsUpdate",
    freshdesk_domain: normalizeDomain(refs.domain.value),
    installed_at: new Date().toISOString(),
    installer_name: getInstallerName(),
    installer_email: getInstallerEmail(),
    marketing_consent: false,
    consent_timestamp: null,
  };
}

// First installs are captured by the onAppInstall server handler; this covers later settings edits.
async function captureSettingsUpdate() {
  if (!hasExistingInstallationConfig()) {
    return;
  }

  try {
    await state.client.request.invokeTemplate("capture_installation", {
      context: {},
      body: JSON.stringify(buildSettingsCapturePayload()),
    });
  } catch (error) {
    console.error("Settings contact capture failed:", error);
  }
}

function showMessage(element, message, type) {
  element.textContent = message;
  element.className = `message ${type}`;
}

function clearMessage(element) {
  element.textContent = "";
  element.className = "message";
}

function safeParseJson(value, fallback) {
  if (!value) {
    return fallback;
  }

  if (typeof value === "object") {
    return value;
  }

  try {
    return JSON.parse(value);
  } catch {
    return fallback;
  }
}

function escapeHtml(value) {
  return String(value || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function postConfigs() {
  const trelloToken = getActiveTrelloToken();
  const hasMaskedTrelloToken = trelloToken === getSecureIparamsMask();
  return {
    __meta: {
      secure: ["trello_token", "api_key"],
    },
    trello_bridge_host: getActiveTrelloBridgeHost(),
    trello_token: trelloToken,
    trello_token_fingerprint: hasMaskedTrelloToken
      ? state.savedConfigs.trello_token_fingerprint || ""
      : buildTokenFingerprint(trelloToken),
    trello_token_saved_at: hasMaskedTrelloToken
      ? state.savedConfigs.trello_token_saved_at || ""
      : trelloToken
      ? new Date().toISOString()
      : "",
    trello_member_name: state.connectedTrelloMember ? state.connectedTrelloMember.name : "",
    trello_member_username: state.connectedTrelloMember ? state.connectedTrelloMember.username : "",
    trello_member_url: state.connectedTrelloMember ? state.connectedTrelloMember.url : "",
    domain: normalizeDomain(refs.domain.value),
    api_key: getActiveFreshdeskAuth(),
    installer_name: getInstallerName(),
    installer_email: getInstallerEmail(),
    marketing_consent: false,
    trello_to_freshdesk_sync_mode: resolvePrimaryNotificationMode(
      state.notificationPreferences.trelloToFreshdesk,
      DEFAULT_TRELLO_TO_FRESHDESK_ACTION
    ),
    freshdesk_to_trello_sync_mode: resolvePrimaryNotificationMode(
      state.notificationPreferences.freshdeskToTrello,
      DEFAULT_FRESHDESK_TO_TRELLO_ACTION
    ),
    trello_to_freshdesk_notifications: state.notificationPreferences.trelloToFreshdesk,
    freshdesk_to_trello_notifications: state.notificationPreferences.freshdeskToTrello,
  };
}

function resolvePrimaryNotificationMode(group, fallbackValue) {
  const values = Object.values(group || {}).filter(Boolean);
  return values.length ? values[0] : fallbackValue;
}

function getConfigs(configs) {
  state.savedConfigs = configs || {};
  if (state.initialized) {
    void hydrateFromConfigs(state.savedConfigs);
  }
}

async function validate() {
  await ensureInitialized();

  if (!getActiveTrelloBridgeHost()) {
    showMessage(refs.trelloMessage, "Trello bridge is required.", "error");
    return false;
  }

  if (!state.trelloVerified) {
    showMessage(refs.trelloMessage, "Connect Trello before installing.", "error");
    return false;
  }

  if (!normalizeDomain(refs.domain.value)) {
    showMessage(refs.freshdeskMessage, "Freshdesk domain is required.", "error");
    return false;
  }

  if (!state.freshdeskVerified) {
    showMessage(refs.freshdeskMessage, "Verify Freshdesk before installing.", "error");
    return false;
  }

  const installerName = getInstallerName();
  const installerEmail = getInstallerEmail();

  if (!installerName) {
    showMessage(refs.installerNameMessage, "Please enter your full name.", "error");
    return false;
  }

  if (!installerEmail) {
    showMessage(refs.installerEmailMessage, "Please enter your email address.", "error");
    return false;
  }

  if (!isValidEmail(installerEmail)) {
    showMessage(refs.installerEmailMessage, "Please enter a valid email address.", "error");
    return false;
  }

  await captureSettingsUpdate();

  return true;
}

window.postConfigs = postConfigs;
window.getConfigs = getConfigs;
window.validate = validate;
